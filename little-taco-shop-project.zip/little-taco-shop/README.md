# The Little Taco Shop

A responsive beginner-friendly restaurant website built with HTML, CSS, and JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — responsive layout, colours, typography, and card styles
- `script.js` — mobile navigation, footer year, and demo contact-form response

## Run
1. Extract the project folder.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the Live Server extension.

## Features
- Responsive navigation
- Hero section and food imagery
- About section
- Menu cards with sample prices
- Opening hours
- Contact form with browser-side required-field validation
- Mobile-friendly layout and keyboard focus styles

## Notes
- Internet is required for the remote food images and Google Fonts.
- Menu items, prices, hours, address, and email are sample project content.
- The contact form does not send email or store messages. A backend or form service is needed for that.
