const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
const contactForm = document.getElementById("contactForm");
const formResponse = document.getElementById("formResponse");
const year = document.getElementById("year");

// Keep the footer year current.
year.textContent = new Date().getFullYear();

// Open and close the mobile navigation menu.
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

// Close the mobile navigation after choosing a section.
mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

// Demo contact form: validates through HTML and displays a confirmation.
// It does not send or store the message.
contactForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  if (!name) {
    formResponse.textContent = "Please enter your name.";
    return;
  }

  formResponse.textContent =
    `Thank you, ${name}! Your message was received in this demo.`;
  contactForm.reset();
});
